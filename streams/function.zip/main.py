
def lambda_handler(event, context):
    print('Nuevo evento')
    print(event)